<?php 

include "db.php"; 

if (isset($_GET['h_id'])) {

    $h_id = $_GET['h_id'];

    $sql = "DELETE FROM `hobbies` WHERE `h_id`='$h_id'";

     $result = $conn->query($sql);

     if ($result == TRUE) {
        ?>
        <script>
        if(window.confirm('Data Deleted succesfully '))
        {
            window.location.href='view_hobby.php';
        };</script>
        <?php
    }else{
        echo "Error:" . $sql . "<br>" . $conn->error;
    }
}  

?>