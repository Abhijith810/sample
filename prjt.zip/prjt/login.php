<?php
// session_start();
include "db.php";

$id = $_POST["email"];
$password = $_POST["password"];


$sql = mysqli_query($conn, "SELECT count(*) as total,user_id from user WHERE email = '".$id."' and
	password = '".$password."'");

$row = mysqli_fetch_array($sql);

if($row["total"] > 0){
	$_SESSION['email']= $id;
	$_SESSION['user_id']=$row["user_id"];
	header('location:index.php');
}
else{
	if($id=="admin@gmail.com"&& $password=="admin")
	{
			header('location:admin.php');
	}
	else{
		
	?><script>
		if(window.confirm)
		{
			window.location.href='login.html';
		};</script>
	
	<?php
	}
}